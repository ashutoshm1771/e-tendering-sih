package sih;

public class bidderrecord {
	public String bidderid;
	public String bname;
	public String badhar;
	public String bpan;
	
	public String bphno;
	public String bemail;
	public String bpass;
	public String bstate;
	public String bdist;
	public String bpincode;
	public String getBidderid() {
		return bidderid;
	}
	public void setBidderid(String bidderid) {
		this.bidderid = bidderid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBadhar() {
		return badhar;
	}
	public void setBadhar(String badhar) {
		this.badhar = badhar;
	}
	public String getBpan() {
		return bpan;
	}
	public void setBpan(String bpan) {
		this.bpan = bpan;
	}
	public String getBphno() {
		return bphno;
	}
	public void setBphno(String bphno) {
		this.bphno = bphno;
	}
	public String getBemail() {
		return bemail;
	}
	public void setBemail(String bemail) {
		this.bemail = bemail;
	}
	public String getBpass() {
		return bpass;
	}
	public void setBpass(String bpass) {
		this.bpass = bpass;
	}
	public String getBstate() {
		return bstate;
	}
	public void setBstate(String bstate) {
		this.bstate = bstate;
	}
	public String getBdist() {
		return bdist;
	}
	public void setBdist(String bdist) {
		this.bdist = bdist;
	}
	public String getBpincode() {
		return bpincode;
	}
	public void setBpincode(String bpincode) {
		this.bpincode = bpincode;
	}

}

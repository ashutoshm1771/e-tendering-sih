package sih;

public class bidderenrollrecord {
	public String regno;
	public String comname;
	public String pbidder;
	public String pcategory;
	public String eyear;
	public String natureofb;
	public String legalstatus;
	public String comcat;
	public String npd;
	public String biddertype;
	public String country;
	public String sc;
	public String postalcode;
	public String ccity;
	public String cstate;
	public String cpcode;
	public String cdist;
	public String cpan;
	
	
	public String getPbidder() {
		return pbidder;
	}
	public void setPbidder(String pbidder) {
		this.pbidder = pbidder;
	}
	public String getPcategory() {
		return pcategory;
	}
	public void setPcategory(String pcategory) {
		this.pcategory = pcategory;
	}
	public String getEyear() {
		return eyear;
	}
	public void setEyear(String eyear) {
		this.eyear = eyear;
	}
	public String getNatureofb() {
		return natureofb;
	}
	public void setNatureofb(String natureofb) {
		this.natureofb = natureofb;
	}
	public String getLegalstatus() {
		return legalstatus;
	}
	public void setLegalstatus(String legalstatus) {
		this.legalstatus = legalstatus;
	}
	public String getComcat() {
		return comcat;
	}
	public void setComcat(String comcat) {
		this.comcat = comcat;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getSc() {
		return sc;
	}
	public void setSc(String sc) {
		this.sc = sc;
	}
	public String getPostalcode() {
		return postalcode;
	}
	public void setPostalcode(String postalcode) {
		this.postalcode = postalcode;
	}
	public String getCdist() {
		return cdist;
	}
	public void setCdist(String cdist) {
		this.cdist = cdist;
	}
	public String mobile;
	public String cname;
	public String dob;
	public String designation;
	public String csign;
	
	
	
	public String getRegno() {
		return regno;
	}
	public void setRegno(String regno) {
		this.regno = regno;
	}
	public String getComname() {
		return comname;
	}
	public void setComname(String comname) {
		this.comname = comname;
	}
	
	public String getNpd() {
		return npd;
	}
	public void setNpd(String npd) {
		this.npd = npd;
	}
	public String getBiddertype() {
		return biddertype;
	}
	public void setBiddertype(String biddertype) {
		this.biddertype = biddertype;
	}
	public String getCcity() {
		return ccity;
	}
	public void setCcity(String ccity) {
		this.ccity = ccity;
	}
	public String getCstate() {
		return cstate;
	}
	public void setCstate(String cstate) {
		this.cstate = cstate;
	}
	public String getCpcode() {
		return cpcode;
	}
	public void setCpcode(String cpcode) {
		this.cpcode = cpcode;
	}
	public String getCpan() {
		return cpan;
	}
	public void setCpan(String cpan) {
		this.cpan = cpan;
	}
	
	
	
	
	
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getCsign() {
		return csign;
	}
	public void setCsign(String csign) {
		this.csign = csign;
	}
	
	
	

}

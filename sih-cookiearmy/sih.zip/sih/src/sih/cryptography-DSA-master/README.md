# cryptography-DSA
Task 3 - implementation of DSA algorithm

package sih;

public class digilockerloginrecord {
	public String fname;
	public String userid;
	public String dpass;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getDpass() {
		return dpass;
	}
	public void setDpass(String dpass) {
		this.dpass = dpass;
	}

}

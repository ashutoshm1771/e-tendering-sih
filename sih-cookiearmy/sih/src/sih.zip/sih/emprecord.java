package sih;

public class emprecord {
	public String empid;
	public String ename;
	public String eadhar;
	public String esign;
	public String govtid;
	public String ephno;
	public String email;
	public String pass;
	public String state;
	public String dist;
	public String pincode;
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEadhar() {
		return eadhar;
	}
	public void setEadhar(String eadhar) {
		this.eadhar = eadhar;
	}
	public String getEsign() {
		return esign;
	}
	public void setEsign(String esign) {
		this.esign = esign;
	}
	public String getGovtid() {
		return govtid;
	}
	public void setGovtid(String govtid) {
		this.govtid = govtid;
	}
	public String getEphno() {
		return ephno;
	}
	public void setEphno(String ephno) {
		this.ephno = ephno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDist() {
		return dist;
	}
	public void setDist(String dist) {
		this.dist = dist;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
}
